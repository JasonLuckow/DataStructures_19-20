// --------------------------------------------------------------------------------
// AUTHOR: Jason Luckow
// Collaborators: Matthew Padgett, Harrison Spencer, Coby Kromis (Function design)

// FILENAME: Lab4.cpp

// SPECIFICATION: To get familiar with stacks and perform push, pop on 
//					 the stack. Also to see if stack is empty or full. Program mainly 
//						converts a decimal number to any base between 2 - 27

// FOR: CS 2413 Data Structure Lab Section 504(I am in section 504 but I submit to 503)

// TEST CASE for DecimalToBase:
// Test case1: Converts a decimal number to another base
//				using all of the functions
// Input: *conv, decimal, base
// Output: A converted decimal #
// --------------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

using namespace std;
#define MAX 8
char Stack[MAX]; 
int top = -1;

int Push(char Stack[], char val);
/*NAME: Push
INPUT PARAMETERS: Stack, val
PURPOSE: To push a character onto the stack*/

char Pop(char Stack[]);
/*NAME: Pop
INPUT PARAMETERS: Stack
OUTPUT: Top character
PURPOSE: Removes top character and displays it*/

void Display(char *conv);
/*NAME: Display
INPUT PARAMETERS: *st
PURPOSE: to display a stack*/

bool isEmpty(char Stack[]);
/*NAME: isEmpty
INPUT PARAMETERS: Stack
OUTPUT: 1 or 0 
PURPOSE: To tell if a stack is empty*/

bool isFull(char Stack[]);
/*NAME: isFull
INPUT PARAMETERS: Stack
OUTPUT: 1 or 0
PURPOSE: to tell if a stack is full*/

char DecimalToBase(char *conv, int decimal, int base);
/*NAME: DecimalToBase
INPUT PARAMETERS: *conv, decimal, base
OUTPUT: converted decimal #
PURPOSE: to convert a decimal number to another base*/


int main(){
	
	int decimal, base;
	char repeat;
	
	char * conv = (char *) malloc(sizeof(char) * MAX);
	
	for(int i = 0; i < MAX; i++) {
		//initializes to NULL
		conv[i] = NULL;
	}
	
	do{

		cout << "Please enter a decimal number: ";
		cin >> decimal;

		cout << "\nPlease enter the conversion base: ";
		cin >> base;
		
		DecimalToBase(conv, decimal, base);
		
		cout << "\nYour base " << base << " representation of the number " << decimal << " is: ";
		Display(conv);
		
		cout << "\n\n\t\tWould you like to continue? (Y or y) ";
		cin >> repeat;
		
		cout << "\n\n";
	}while(repeat == 'y' || repeat =='Y');
	
	free(conv);
	
	return 0;
}

int Push(char Stack[], char val){
	
	if(isFull(Stack)){
		
		//cout << "\nStack overflow!\n";
		return -1;
	}
	
	else{
		
		top++; //Increases top 
		Stack[top] = val; //Sets stack position to character value
	}
	
	return 0;
}

char Pop(char Stack[]){
	
	char val = ' ';
	
	if(isEmpty(Stack)){
		
		//cout << "\nStack underflow!\n";
		return -1;
	}
	
	else{
		
		val = Stack[top]; //Saves top value
		Stack[top] = NULL; //Gets rid of top 
		top--; //Lowers top index
		return val;
	}
}

void Display(char *conv){
	
	for(int i = 0; i < MAX; i++)
		cout << conv[i] << " ";
}

bool isEmpty(char Stack[]){
	
	if(Stack[0] == NULL)
		return true; //Returns true if the first index is NULL
		
	else
		return false;
}

bool isFull(char Stack[]){
	
	if(top == MAX - 1)
		return true; //Returns true if top index is equal to MAX -1
		
	return false;
}

char DecimalToBase(char *conv, int decimal, int base){
	
	int remainder, count = MAX;
	
	while(decimal > 1){
		
		remainder = decimal % base;
		
		switch(remainder){
			
			case 10:
				Push(Stack, 'A');
				break;
			
			case 11:
				Push(Stack, 'B');
				break;
			
			case 12:
				Push(Stack, 'C');
				break;
			
			case 13:
				Push(Stack, 'D');
				break;
			
			case 14:
				Push(Stack, 'E');
				break;
			
			case 15:
				Push(Stack, 'F');
				break;
			
			case 16:
				Push(Stack, 'G');
				break;
			
			case 17:
				Push(Stack, 'H');
				break;
			
			case 18:
				Push(Stack, 'I');
				break;
			
			case 19:
				Push(Stack, 'J');
				break;
			
			case 20:
				Push(Stack, 'K');
				break;
			
			case 21:
				Push(Stack, 'L');
				break;
			
			case 22:
				Push(Stack, 'M');
				break;
			
			case 23:
				Push(Stack, 'N');
				break;
			
			case 24:
				Push(Stack, 'O');
				break;
			
			case 25:
				Push(Stack, 'P');
				break;
			
			case 26:
				Push(Stack, 'Q');
				break;
			
			case 27:
				Push(Stack, 'R');
				break;
			
			default:
				Push(Stack, (char)remainder + '0');
				break;
			
		}
		
		decimal = decimal / base;
		count--;
		
	}

	Push(Stack, (char)decimal + '0');
	count--;
	
	for(int i = 0; i < count; i++)
		Push(Stack, '0');
	
	for(int i = 0; i < MAX; i++)
		conv[i] = Pop(Stack);
}
