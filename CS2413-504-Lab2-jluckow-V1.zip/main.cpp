// --------------------------------------------------------------------------------
// AUTHOR: Jason Luckow
// Collaborators: Matthew Padgett, Harrison Spencer, Coby Kromis (Function design)

// FILENAME: Lab2.cpp

// SPECIFICATION: To get familiar with stacks and perform push, pop, peek on 
//					 the stack. Also to see if stack is empty or full and if 
//						an infix equation is balanced. Code also converts infix
//							to postfix.

// FOR: CS 2413 Data Structure Lab Section 503

// TEST CASE for InfixtoPostfix:
// Test case1: Converts infix expression to a postfix expression 
//				using all of the functions
// Input: Func, Postfix
// Output: A postfix expression converted from infix
// --------------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

using namespace std;
#define MAX 75
char Stack[MAX]; 
int top = -1;

void Push(char Stack[], char val);
/*NAME: Push
INPUT PARAMETERS: Stack, val
PURPOSE: To push a character onto the stack*/

char Pop(char Stack[]);
/*NAME: Pop
INPUT PARAMETERS: Stack
OUTPUT: Top character
PURPOSE: Removes top character and displays it*/

char Peek(char Stack[]);
/*NAME: Peek
INPUT PARAMETERS: Stack
OUTPUT: The character on top of the stack
PURPOSE: To show the character at the top of the stack*/

void Display(char *st);
/*NAME: Display
INPUT PARAMETERS: *st
PURPOSE: to display a stack*/

bool isEmpty(char Stack[]);
/*NAME: isEmpty
INPUT PARAMETERS: Stack
OUTPUT: 1 or 0 
PURPOSE: To tell if a stack is empty*/

bool isFull(char Stack[]);
/*NAME: isFull
INPUT PARAMETERS: Stack
OUTPUT: 1 or 0
PURPOSE: to tell if a stack is full*/

bool isBalance(char Func[]);
/*NAME: isBalance
INPUT PARAMETERS: Func
OUTPUT: 1 or 0
PURPOSE: To tell if expression is balanced*/

char InfixToPostfix(char Func[], char *Postfix);
/*NAME: InfixToPostfix
INPUT PARAMETERS: Func, *Postfix
OUTPUT: Postfix expression
PURPOSE: to convert infix to postfix*/

int getPriority(char op);
/*NAME: getPriority
INPUT PARAMETERS: op
OUTPUT: 1 or 0
PURPOSE: to find operation priority*/

int main(){
	
	char Func[MAX] = "A-(B/C+(D%E*F)/G)*H";
	char * Postfix = (char *) malloc(sizeof(char) * MAX);
	
	//Test case 1:
	cout << "TEST CASE for InfixtoPostfix (Uses all functions in code):\n";
	cout << "Postfix Expression:\n\n\t";
	InfixToPostfix(Func, Postfix);
	Display(Postfix);

	cout << "\n";

	system("pause");
	
	free(Postfix);
	
	return 0;
}

void Push(char Stack[], char val){
	
	if(isFull(Stack)){
		
		cout << "\nStack overflow!\n";
		//return -1;
	}
	
	else{
		
		top++; //Increases top 
		Stack[top] = val; //Sets stack position to character value
	}
}

char Pop(char Stack[]){
	
	char val = ' ';
	
	if(top == -1){
		
		cout << "\nStack underflow!\n";
		return -1;
	}
	
	else{
		
		val = Stack[top]; //Saves top value
		Stack[top] = NULL; //Gets rid of top 
		top--; //Lowers top index
		return val;
	}
}

char Peek(char Stack[]){
	
	if(Stack[0] == NULL){
		
		cout << "\nStack is empty!\n";
		return -1;
	}
	
	else
		return Stack[top]; //Returns only top value of stack
}

void Display(char *st){
	
	for(int i = 0; i < MAX; i++)
		cout << st[i] << " ";
}

bool isEmpty(char Stack[]){
	
	if(Stack[0] == NULL)
		return true; //Returns true if the first index is NULL
		
	else
		return false;
}

bool isFull(char Stack[]){
	
	if(top == MAX - 1)
		return true; //Returns true if top index is equal to MAX -1
		
	return false;
}

bool isBalance(char Func[]){
	
	for(int i = 0; i < MAX - 1; i++){
		
		if(Func[i] == '[' || Func[i] == '{' || Func[i] == '(')
			Push(Stack, Func[i]); //Finds open state and pushes it to the stack
			
		//Looks for closing state and matches it to open state
		if(Func[i] == ']' && Pop(Stack) != '[')
			return 0;
			
		if(Func[i] == '}' && Pop(Stack) != '{')
			return 0;
		
		if(Func[i] == ')' && Pop(Stack) != '(')
			return 0;
	}
	return 1;
}

char InfixToPostfix(char Func[], char *Postfix){
	
	int i = 0; //Index for Func
	int j = 0; //Index for Postfix
	char temp;
	
	//Checks if equation is balanced
	if(isBalance(Func) == false)
		cout << "Equation is not balanced.";
	
	//Initializes Postfix
	for(int i = 0; i < MAX; i++) {
		
		Postfix[i] = NULL;
	}
	
	Push(Stack, '(');
	while(Func[i] != '\0'){
		
		if(Func[i] == '('){
			//Looks for ( and pushes it to the stack
			Push(Stack, Func[i]);
			i++;
		}
		else if(Func[i] == ')'){
			//Looks for ) and pushes everything to the left of it 
			//to postfis except (
			while((top != -1) && (Peek(Stack) != '(')){
				
				Postfix[j] = Pop(Stack);
				j++;
			}
			
			if(top == -1){
				
				cout << "Stack is empty";
				exit(1);
			}
	
			temp = Pop(Stack); //Deletes left Parenthesis
			i++;
			
		}
		else if(isdigit(Func[i]) || isalpha(Func[i])){
			//Checks for letter or number
			Postfix[j] = Func[i];
			j++;
			i++;
		}
		else if(Func[i] == '+' || Func[i] == '-' || Func[i] == '*' || Func[i] == '/' || Func[i] == '%'){
			//Looks for math operators
			while(((top != -1) && (Peek(Stack) != '(')) && ((getPriority(Peek(Stack))) > (getPriority(Func[i])))){
				
				Postfix[j] = Pop(Stack);
				j++;
			}
			
			Push(Stack, Func[i]);
			i++;
		}
		else{
			
			cout << "Invalid operand!";
			exit(1);
		}
	}
	
	while((top != -1) && (Peek(Stack) != '(')){
		
		Postfix[j] = Pop(Stack);
		j++;
	}
	
	Postfix[j] = '\0';
}

int getPriority(char op){
	
	if(op == '*' || op == '/' || op == '%'){
		
		return 1;
	}
	else{
		
		return 0;
	}
}