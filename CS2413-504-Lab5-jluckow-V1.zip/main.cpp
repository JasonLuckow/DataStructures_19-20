// --------------------------------------------------------------------------------
// AUTHOR: Jason Luckow
//Collaborators: Matthew Padgett, Harrison Spencer, Coby Kromis (Function design)

//Adapted from Lab1

// FILENAME: Lab5.cpp

// SPECIFICATION: To get familiar with doubly linked lists
//									and common linked list operations.

// FOR: CS 2413 Data Structure Lab Section 504(I am in section 504 but I submit to 503)

// TEST CASES for Create doubly Linked List and operations:
// Test case1: asks the user how many nodes they would like in the list
//						and the data to be entered
// Output: a doubly linked list with delete, insert, and reverse operations
// --------------------------------------------------------------------------------

#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <cmath>

using namespace std;

struct node{
    int data;
    struct node *next, *prev;
};

typedef node NODE;

NODE *create_node(int val);
/*NAME: create_node
INPUT PARAMETERS: val
OUTPUT: none
PURPOSE: to create a node in a linked list*/

void display(NODE *head, int numnodes);
/*NAME: display
INPUT PARAMETERS: head, numnodes
OUTPUT: a doubly linked list
PURPOSE: to display a doubly linked list*/

NODE *insert_beg(NODE *,NODE* new_node);
/*NAME: insert_beg
INPUT PARAMETERS: struct node, new node
OUTPUT: none
PURPOSE: to insert a node at the begining of a list*/

NODE *delete_end(NODE *, int &numnodes);
/*NAME: delete_end
INPUT PARAMETERS: struct node, numnodes
OUTPUT: none
PURPOSE: to delete a node at the end of a list*/

NODE *reverse(NODE *head);
/*NAME: reverse
INPUT PARAMETERS: struct node
OUTPUT: none
PURPOSE: to reverse a doubly linked list*/

int main(int argc, char *argv[]){
	
	NODE *head = NULL;
	
	int data, numnodes;
	
	cout << "How many nodes would you like entered to the list? ";
	cin >>numnodes;
	cout << "\n";
	
	for(int i = 0; i < numnodes; i++){
		
		cout << "Enter the data for node " << i << ": ";
		cin >> data;
		head = insert_beg(head, create_node(data));
	}
	
	cout << "\nOriginal doubly linked list: \n";
	display(head, numnodes);
	
	cout << "\nReversed doubly linked list: \n";
	head = reverse(head);
	display(head, numnodes);
	
	cout << "\nDoubly linked list with deleted end: \n";
	head = delete_end(head, numnodes);
	display(head, numnodes);
	
	cout << "\n";
	
	system("pause");
	return 0;
}

NODE *create_node(int val){
	
	NODE *new_node;
	
	new_node = (NODE*)malloc(sizeof(NODE));
	new_node -> data = val;		//the data inside the new node is the value entered
	new_node -> next = NULL;
	new_node -> prev = NULL;
	
	return new_node;
}

void display(NODE *head, int numnodes){
	
	if(head == NULL){
		
		cout << "\nThe list is empty!";
	}
	
	while(head != NULL){
		
		if(numnodes > 1){
			
			cout << head -> data << " <-> ";
			head = head -> next;
			numnodes--;
		}
		else{
		
			cout << head -> data;
			head = head -> next;
		}
	}
	
	cout << "\n";
}

NODE *insert_beg(NODE *head, NODE* new_node){

	new_node -> prev = NULL;
	
    new_node -> next = head; 
  
    if (head != NULL) 
        head -> prev = new_node; 
  
    head = new_node; 
	
	return new_node;
}

NODE *delete_end(NODE *head, int &numnodes){
	
	NODE *ptr;
	
	ptr = head;
	
	if(ptr == NULL)
		return head;
	
	while(ptr -> next != NULL)
		ptr = ptr -> next;
	
	ptr -> prev -> next = NULL;
	
	free(ptr);
	
	numnodes--;
	
	return head;
}

NODE *reverse(NODE *head){
	
	if(!head)
		return NULL;
		
	NODE *temp;
	
	temp = head -> next;
	head -> next = head -> prev;
	head -> prev = temp;
	
	if(!head -> prev)
		return head;
		
	return reverse(head -> prev);
}