/*--------------------------------------------------------------------------------
AUTHOR: Jason Luckow
Collaborators/Sources: 
		Matthew Padgett, Harrison Spencer, Coby Kromis (Function design)
	and from: www.techiedelight.com/circular-queue-implementation-c/struct queue

FILENAME: Lab3.cpp

SPECIFICATION: to implement a 3 level priority queue with arrays where each of the
	three arrays holds 10 integers which are randomly generated. functions are 
		available to remove/add elements, and to see if the priority queue is 
			empty or full. Program mainly uses the simulation function to simulate
				traffic in the queue. the simulate function utilizes all other 
					functions in this program

FOR: CS 2413 Data Structure Lab Section 504(I am in section 504 but I submit to 503)

TEST CASE for simulate:
Test case1: simulates traffic in the 3 level priority queue by utilizing all 
				all other functions
Input: *pt1, *pt2, *pt3
Output: A postfix expression converted from infix
--------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <ctime>

int totalQueue = 0;

using namespace std;

struct queue{
	
	int *items;		// array to store queue elements
	int maxsize;	// maximum capacity of the queue
	int front;		// front points to front element in the queue (if any)
	int rear;		// rear points to last element in the queue
	int size;		// current capacity of the queue
};

struct queue* newQueue(int size);
/*NAME: newQueue
INPUT PARAMETERS: size
PURPOSE: initialize queue
*/

int size(struct queue *pt);
/*NAME: size
INPUT PARAMETERS: *pt
PURPOSE: return the size of the queue
*/

int isEmpty(struct queue *pt);
/*NAME: isEmpty
INPUT PARAMETERS: *pt
PURPOSE: check if the queue is empty or not
*/

int isFull(struct queue *pt);
/*NAME: isFull
INPUT PARAMETERS: *pt
PURPOSE: checks if the queue is full
*/

int front(struct queue *pt);
/*NAME: front
INPUT PARAMETERS: *pt
PURPOSE: return front element in queue
*/

int enqueue(struct queue *pt, int x);
/*NAME: enqueue
INPUT PARAMETERS: *pt, x
PURPOSE: add an element x in the queue
*/

int dequeue(struct queue *pt1, struct queue *pt2, struct queue *pt3);
/*NAME: dequeue
INPUT PARAMETERS: *pt1, *pt2, *pt3
PURPOSE: remove element from the queue
*/

void display(struct queue *pt);
/*NAME: display
INPUT PARAMETERS: *pt
PURPOSE: displays all 3 priority queues
*/

int randomEl();
/*NAME: randomEl
INPUT PARAMETERS: NA
PURPOSE: generates a random integer
*/

int simulate(struct queue *pt1, struct queue *pt2, struct queue *pt3);
/*NAME: simulate
INPUT PARAMETERS: *pt1, *pt2, *pt3
PURPOSE: simulates traffic in the queue per step 2 in the lab instructions
*/

int main(){
	
	srand(time(NULL));
	
	//Creates the 3 priority queues
	struct queue *pt1 = newQueue(10); //Priority 1
	struct queue *pt2 = newQueue(10); //Priority 2
	struct queue *pt3 = newQueue(10); //Priority 3

	//simulation function uses all functions
	simulate(pt1, pt2, pt3);
	
	free(pt1);
	free(pt2);
	free(pt3);
	
	system("pause");
	
	return 0;
}

struct queue* newQueue(int size){
	
	struct queue *pt = NULL;
	pt = (struct queue*)malloc(sizeof(struct queue));
	
	pt->items = (int*)malloc(size * sizeof(int));
	pt->maxsize = size;
	pt->front = 0;
	pt->rear = -1;
	pt->size = 0;
	
	for(int i = 0; i < pt -> maxsize; i++) {
		//initializes to NULL
		pt -> items[i] = NULL;
	}

	return pt;
}

int size(struct queue *pt){
	
	return pt->size;
}

int isEmpty(struct queue *pt){
	
	return !size(pt);
}

int isFull(struct queue *pt){
	
	return size(pt) == pt->maxsize;
}

int front(struct queue *pt){
	
	if (isEmpty(pt))
	{
		cout << "UnderFlow\nProgram Terminated\n";
		return -1;
	}

	return pt->items[pt->front];
}

int enqueue(struct queue *pt, int x){
	
	if (isFull(pt))
	{
		return -1;
	}
	else{
		
		pt->rear = (pt->rear + 1) % pt->maxsize;	// circular queue
		pt->items[pt->rear] = x;
		pt->size++;
		totalQueue++;
	}
}

int dequeue(struct queue *pt1, struct queue *pt2, struct queue *pt3){
	
	int val;
	
	if(isEmpty(pt1)) // front == rear
	{
		
		if(isEmpty(pt2)){
			
			if(isEmpty(pt3)){
				
				return -1;
				
			}
			else{
				val = pt3 -> items[pt3->front];
				pt3->items[pt3->front] = NULL;
				pt3->front = (pt3->front + 1) % pt3->maxsize;	// circular queue
				pt3->size--;
			}
		}
		else{
			
			val = pt2 -> items[pt2->front];
			pt2->items[pt2->front] = NULL;
			pt2->front = (pt2->front + 1) % pt2->maxsize;	// circular queue
			pt2->size--;
		}
	}
	else{
		val = pt1 -> items[pt1->front];
		pt1->items[pt1->front] = NULL;
		pt1->front = (pt1->front + 1) % pt1->maxsize;	// circular queue
		pt1->size--;
	}
	
	totalQueue--;
	return val;
}

void display(struct queue *pt1, struct queue *pt2, struct queue *pt3){
	
	cout << "\nQueue 1\n";
	cout << "front = " << pt1 -> front << "   " << "rear = " << pt1->rear << "\n";
    for(int i = 0; i < pt1 -> maxsize; i++) {
		
		cout << pt1 -> items[i] << " ";
	}
	
	cout << "\n\n";
	
	cout << "Queue 2\n";
	cout << "front = " << pt2 -> front << "   " << "rear = " << pt2->rear << "\n";
    for(int i = 0; i < pt2 -> maxsize; i++) {
		
		cout << pt2 -> items[i] << " ";
	}
	
	cout << "\n\n";
	
	cout << "Queue 3\n";
	cout << "front = " << pt3 -> front << "   " << "rear = " << pt3->rear << "\n";
    for(int i = 0; i < pt3 -> maxsize; i++) {
		
		cout << pt3 -> items[i] << " ";
	}
	
	cout << "\n\n";
	
}

int randomEl(){
	
	return rand() % 899 + 100;
}

int simulate(struct queue *pt1, struct queue *pt2, struct queue *pt3){
	
	int count = 0, init = 6;
	//Qstat checks to see if enqueue or dequeue functions returns
	//overflows or underflows
	int exitTimes = 0, Qstat = 0;
	
	while(exitTimes < 20){
		//ends when 20 elements have exited the queue
		switch(rand() % 3 + 1){
		// + 1 so range is from 1 to 3 instead of 0 to 3
		
		//switches between a random # 1,2,3 to assign that priorit to a 
		//randomly generated # between 100-999
			case 1:
				Qstat = enqueue(pt1, randomEl());
				count++;
				break;
			case 2:
				
				Qstat = enqueue(pt2, randomEl());
				count++;
				break;
			case 3:
				
				Qstat = enqueue(pt3, randomEl());
				count++;
				break;
		}
		
		if(Qstat == -1){
				cout << "OverFlow\nProgram Terminated\n";
				return -1;
		}
		
		//init is initially set for the first 6 elements in the queue 
		//then changes to three after it has ran through once
		if(count == init){
			
			cout << "------------INITIAL STATE WITH " << totalQueue << " ELEMENTS---------------";
			display(pt1, pt2, pt3);
			
			//exit chooses either 0 or 1 to decide if either 
			//2 or 4 elements exit the queue
			int exit = rand() % 2;
			
			if(exit == 0){
				
				for(int i = 0; i < 2; i++) {
					
					Qstat = dequeue(pt1, pt2, pt3);
					
					if(Qstat == -1) {
						
						cout << "UnderFlow\nProgram Terminated\n";
						return -1;
					}
				}
				//prints the current state of the queue after dequeue
				cout << "----------------------CURRENT STATE---------------------------";
				display(pt1, pt2, pt3);
				
				init = 3;
				exitTimes = exitTimes + 2;
				count = 0;
			}
			if(exit == 1){
				
				for(int i = 0; i < 4; i++) {
					
					Qstat = dequeue(pt1, pt2, pt3);
					
					if(Qstat == -1) {
						
						cout << "UnderFlow\nProgram Terminated\n";
						return -1;
					}
				}
				//prints the current state of the queue after dequeue
				cout << "----------------------CURRENT STATE---------------------------";
				display(pt1, pt2, pt3);
				
				init = 3;
				exitTimes = exitTimes + 4;
				count = 0;
			}
		}
	}
	
	if(exitTimes >= 20){
		cout << "\n20 Elements have exited the queue. Simulation ended\n";
	}
}