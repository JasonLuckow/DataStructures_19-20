// --------------------------------------------------------------------------------
// AUTHOR: Jason Luckow
//Collaborators: Matthew Padgett, Harrison Spencer, Coby Kromis (Function design)

//Some code was adapted from Textbook for this course

// FILENAME: Lab6.cpp

// SPECIFICATION: To get familiar with binary search trees and common 
//								BST operations.

// FOR: CS 2413 Data Structure Lab Section 504(I am in section 504 but I submit to 503)

// TEST CASES:
// Menu allows the user to go through every option. Every function is
// used at least once if you go through all the options
// --------------------------------------------------------------------------------

#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <cmath>
#include <ctime>

using namespace std;

struct node{
	
    int data;
    struct node *left, *right;
};

typedef node NODE;

int randomEl();

NODE *create_tree(NODE *tree, int data);
/*NAME: create_tree
INPUT PARAMETERS: *tree, data
OUTPUT: none
PURPOSE: to create a binar search tree*/

NODE *remove_node(NODE *tree, int data);
/*NAME: remove_node
INPUT PARAMETERS: *tree, data
OUTPUT: none
PURPOSE: remove a specific node in the BST*/

int search_item(NODE *tree, int data);
/*NAME: search_item
INPUT PARAMETERS: *tree, data
OUTPUT: none
PURPOSE: to search for an element in the BST*/

int item_found(NODE *tree, int data);
/*NAME: item_found
INPUT PARAMETERS: *tree, data
OUTPUT: visiting trace path
PURPOSE: to print the trace path of an element found in a BST*/

int height(NODE *tree);
/*NAME: height
INPUT PARAMETERS: *tree
OUTPUT: none
PURPOSE: to find the height of a BST*/

void display(NODE *tree);
/*NAME: display
INPUT PARAMETERS: *tree
OUTPUT: BST in a readable format with "--" for empty leafs
PURPOSE: to display a BST*/

void printLevel(NODE *tree, int level); 
/*NAME: printLevel
INPUT PARAMETERS: *tree, level
OUTPUT: none
PURPOSE: to delete a node at the end of a list*/

NODE *minNode(NODE *node);
/*NAME: minNode
INPUT PARAMETERS: node
OUTPUT: none
PURPOSE:  to find the smallest element in the BST*/

int main(int argc, char *argv[]){
	
	NODE *tree = NULL;
	int option, remnode, search, res, created = 0;
	srand(time(NULL));
	
	do{
		
		cout << "\n**********MAIN MENU**********\n";
		cout <<"\n1. Create an integer binary search tree"; //1
		cout <<"\n2. Remove a specific node in the tree"; // 2
		cout <<"\n3. Search an item in the tree"; // 3
		cout <<"\n4. Display the tree in pyramid shape"; //4
		cout <<"\n5. Exit"; //5
		cout << "\n\nEnter your option: ";
		cin >> option;
		cout << "\n";
		
		switch(option){
			
			case 1:
			
				if(created == 0){
				
					for(int i = 0; i <10; i++)
						tree = create_tree(tree, randomEl());
				}
				else
					cout << "You have already created a tree!\n";
				created = 1;
				break;
				
			case 2: 
			
				if(created == 1){
					
					cout << "Enter the node to be removed: ";
					cin >> remnode;
					remove_node(tree, remnode);
				}
				else
					cout << "TREE NOT CREATED YET!\n";
				break;
				
			case 3:
			
				if(created == 1){
					
					cout << "Enter the number you wish to find in the tree: ";
					cin >> search;
					res = search_item(tree, search);
					if(res){
						
						cout << "\nThe number " << search << " was found in the tree! Here is the visiting trace path:\n";
						item_found(tree, search); cout << search;
						cout << "\n";
					}
				}
				else
					cout << "TREE NOT CREATED YET!\n";
				break;
				
			case 4:
			
				if(created == 1)
					display(tree);
				else
					cout << "TREE NOT CREATED YET!\n";
				break;
		}
	}while(option != 5);
	
	return 0;
}

int randomEl(){
	
	return rand() % 90 + 10;
}

NODE *create_tree(NODE *tree, int data){
	
	NODE *ptr, *nodep, *parentp;
	
	ptr = (NODE*)malloc(sizeof(NODE));
	
	ptr -> data = data;
	ptr -> left = NULL;
	ptr -> right = NULL;
	
	if(tree == NULL){
		
		tree = ptr;
		tree -> left = NULL;
		tree -> right =NULL;
	}
	else{
		
		parentp = NULL;
		nodep = tree;
		while(nodep != NULL){
			
			parentp = nodep;
			if(ptr -> data < nodep ->data)
				nodep = nodep -> left;
			else
				nodep = nodep -> right;
		}
		
		if(ptr -> data < parentp ->data)
			parentp -> left = ptr;
		else
			parentp -> right = ptr;
	}
	
	return tree;
}

NODE *remove_node(NODE *tree, int data){

    if (tree == NULL) 
		return tree; 
  
    if (data < tree -> data) 
        tree->left = remove_node(tree->left, data); 
  
    else if (data > tree -> data) 
        tree->right = remove_node(tree->right, data); 
  
    else{

        if (tree->left == NULL){
 
            NODE *temp = tree->right; 
            free(tree); 
            return temp; 
        } 
        else if (tree->right == NULL){
 
            NODE *temp = tree->left; 
            free(tree); 
            return temp; 
        } 

        NODE *temp = minNode(tree->right); 
  
        tree->data = temp->data; 
  
        tree->right = remove_node(tree->right, temp->data); 
    } 
    return tree; 
}

int search_item(NODE *tree, int data){
	
	if(tree == NULL ){
		
		cout <<"\nITEM NOT IN THE TREE!\n";
		return 0;
	}
	
	if (tree -> data == data)
		return 1;
		
	if(tree -> data < data )
		return search_item(tree -> right, data);
		
	if(tree -> data > data )
		return search_item(tree -> left, data);
		
	return 0;
}

int item_found(NODE *tree, int data){
	
	if(tree == NULL )
		return 0;
	
	if (tree -> data == data)
		return 1;
		
	if(tree -> data < data ){
		
		cout << tree -> data << " -> ";
		return item_found(tree -> right, data);
	}
		
	if(tree -> data > data ){
		
		cout << tree -> data << " -> ";
		return item_found(tree -> left, data);
	}
	
	return 0;
}

int height(NODE *tree){
	
	int lefth, righth;
	
	if(tree == NULL)
		return 0;
		
	else{
		
		lefth = height(tree -> left);
		righth = height(tree -> right);
		
		if(lefth > righth)
			return (lefth + 1);
		else
			return (righth + 1);
	}
}

void display(NODE *tree){
 
    int h = height(tree); 
    int i; 
    for (i=1; i<=h; i++) { 
		
        printLevel(tree, i); 
        cout << "\n\n";
    } 
} 
  
void printLevel(NODE *tree, int level){
 
    if (tree == NULL){ 
		
		cout << "-- ";
        return; 
	}
		
    if (level == 1) 
        cout << tree->data << " "; 
		
    else if (level > 1) {
 
        printLevel(tree -> left, level - 1); 
        printLevel(tree -> right, level - 1); 
    } 
} 

NODE *minNode(NODE *node){
 
    NODE* current = node; 

    while (current && current -> left != NULL) 
        current = current->left; 
  
    return current; 
} 